# reveal-text
Reveal effect for text (and HTML)
