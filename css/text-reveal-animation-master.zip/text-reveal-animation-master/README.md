# text-reveal-animation
Simple Text reveal animation using [Baffle.js](https://camwiegert.github.io/baffle/)

[Demo](https://theakshits.github.io/text-reveal-animation/)
